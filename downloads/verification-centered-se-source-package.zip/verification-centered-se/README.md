# Verification-Centered Software Engineering with Coding Agents

This is the reproducible source package for a NeurIPS 2026 Education Track
submission. It teaches one bounded concept: how an engineer converts an
agent-produced candidate into an evidence-backed, property-scoped, and
human-approved or rejected software change. The learner—not the agent—is the
primary object of improvement.

Start with:

- `paper/main.pdf` — two-page submission;
- `materials/slides/verifier_feedback_loops.pdf` — 16:9 learner-facing classroom deck;
- `materials/slides/Instructor_Notes_Verification_Centered_SE.pdf` — page-aligned A4 instructor companion;
- `materials/notebooks/verifier_feedback_loop.ipynb` — executed notebook;
- `materials/README.md` — teaching sequence and spoiler controls;
- `BUILD.md` — clean build instructions;
- `LICENSE.md`, `THIRD_PARTY.md`, and `MANIFEST.md` — licensing and provenance.

Run the documented virtual-environment command after installing the prerequisites. The build tests all
three exercise repositories, executes the notebook, rebuilds paper and slides,
and creates learner, instructor, and submission ZIP files with SHA-256 checksums.

The two slide PDFs are deliberately complementary: the concise projection deck
controls what learners see and when, while the page-matched instructor PDF
explains each slide's purpose, analogy, and classroom use. See
`materials/slides/README.md`.

The pilot directory contains a ready-to-run small-pilot protocol and an empty
data template. No human-participant outcome is claimed in this release.
