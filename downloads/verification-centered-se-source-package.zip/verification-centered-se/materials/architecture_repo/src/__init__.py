"""Architecture lab package."""
